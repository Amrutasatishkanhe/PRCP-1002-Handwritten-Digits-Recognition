# PRCP-1002: Handwritten Digits Recognition

## 1. Project Overview
The objective is to classify handwritten digits from 0 to 9
using the MNIST dataset and compare different machine learning
and deep learning algorithms.

## 2. Dataset
- Dataset: MNIST
- Training images: 60,000
- Test images: 10,000
- Image dimensions: 28 x 28 pixels
- Number of classes: 10 (digits 0 to 9)
- Pixel values: 0 to 255 before normalization

## 3. Models Compared
- K-Nearest Neighbors (KNN)
- Support Vector Machine (SVM)
- Random Forest
- Artificial Neural Network (ANN/MLP)
- Convolutional Neural Network (CNN)

## 4. Model Comparison
Reported test accuracies from the experiment:
- CNN: 99.16%
- SVM: 96.87%
- ANN/MLP: 95.49%
- Random Forest: 95.44%
- KNN: 94.96%

The CNN achieved the highest reported test accuracy.

## 5. CNN Evaluation
- Test accuracy: 99.16%
- Macro precision: 99.17%
- Macro recall: 99.14%
- Macro F1-score: 99.15%
- Training epochs: 5

## 6. Methodology
The workflow includes dataset loading, data inspection,
pixel normalization, model training, model comparison,
evaluation, and saving the trained CNN model.

## 7. Application
A Streamlit application allows a user to upload a digit image
and view the predicted digit, confidence score, and class
probabilities.

## 8. Limitations
The traditional models were trained on a stratified sample
of 12,000 training images, whereas the CNN used 60,000.
Therefore, the comparison does not use equal training sizes.
Performance on external images can differ from MNIST test
performance because image backgrounds, centering, scale,
and handwriting styles may vary.

## 9. Conclusion
The CNN performed best in the reported experiment, achieving
99.16% test accuracy. The Streamlit application demonstrates
how the trained model can be used for digit prediction.

## 10. Reproducibility
The project includes the Jupyter notebook, model comparison
CSV, and saved CNN model. Run the notebook to reproduce
the analysis and model evaluation, subject to the installed
dependencies and execution environment.
