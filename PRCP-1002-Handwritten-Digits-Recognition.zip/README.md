# PRCP-1002: Handwritten Digits Recognition

## Project Overview
This project classifies handwritten digits from 0 to 9
using the MNIST dataset.

## Models Compared
- K-Nearest Neighbors (KNN)
- Support Vector Machine (SVM)
- Random Forest
- Artificial Neural Network (ANN/MLP)
- Convolutional Neural Network (CNN)

## Best Model
CNN achieved 99.16% test accuracy in the current experiment.

## Project Files
- PRCP-1002_Handwritten_Digits_Recognition.ipynb:
  Data analysis, model training, and evaluation.
- mnist_model_comparison.csv:
  Test-set model comparison metrics.
- models/mnist_cnn_best.keras:
  Saved CNN model.

## Dataset
MNIST handwritten digits dataset (0-9).

## Note
Results may differ on external handwritten images.
The saved notebook should be run to reproduce the experiment.
