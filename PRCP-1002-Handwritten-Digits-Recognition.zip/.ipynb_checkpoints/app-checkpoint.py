import streamlit as st
import numpy as np
from PIL import Image, ImageOps
from tensorflow.keras.models import load_model

st.set_page_config(page_title="Handwritten Digit Recognition", page_icon="✍️")

st.title("Handwritten Digit Recognition")
st.write("Upload an image of a handwritten digit (0–9) to predict it using a CNN model.")

@st.cache_resource
def load_cnn_model():
    model_path = (
        Path(__file__).parent /
        "models" / "mnist_cnn_best.keras"
    )
    return load_model(model_path)

from pathlib import Path

try:
    model = load_cnn_model()
except Exception as e:
    st.error(f"Could not load the model: {e}")
    st.stop()

uploaded_file = st.file_uploader(
    "Choose a digit image",
    type=["png", "jpg", "jpeg", "bmp"]
)

if uploaded_file is not None:
    image = Image.open(uploaded_file).convert("L")
    st.image(image, caption="Uploaded image", width=250)

    # Resize and convert to MNIST-style grayscale input
    processed = ImageOps.fit(image, (28, 28))
    image_array = np.array(processed).astype("float32")

    # MNIST typically has a black background and white digit
    if image_array.mean() > 127:
        image_array = 255 - image_array

    image_array = image_array / 255.0
    image_array = image_array.reshape(1, 28, 28, 1)

    if st.button("Predict digit"):
        predictions = model.predict(image_array, verbose=0)[0]
        predicted_digit = int(np.argmax(predictions))
        confidence = float(predictions[predicted_digit]) * 100

        st.success(f"Predicted digit: {predicted_digit}")
        st.metric("Model confidence", f"{confidence:.2f}%")

        st.subheader("Probability for each digit")
        st.bar_chart({
            str(i): float(predictions[i])
            for i in range(10)
        })
